<?php
// Behar diren "requiere" idatzi.
require_once "db.php";

// Klase definizioa.
class Mendia implements Sailkagarria
{
    private DB $db;

    private ?int $id;
    private string $izena;
    private string $lurraldea;
    private float $distantzia;
    private ?int $desnibela;

    public function __construct(DB $db)
    {
        $this->db = $db;
    }

    #[Override]
    public function zailtasunMaila(): string
    {
        $mezua = "";

        if ($this->desnibela < 500) {
            $mezua = "Erraza";
        } else if ($this->desnibela >= 500 || $this->desnibela <= 999) {
            $mezua = "Ertaina";
        } else if ($this->desnibela >= 1000) {
            $mezua = "Zaila";
        }

        return $mezua;
    }
}


?>


<!DOCTYPE html>
<html lang="eu">

<head>
    <meta charset="UTF-8">
    <title>A4</title>
</head>

<body>
    <!-- Erakutsi hemen mendi zerrenda -->
</body>

</html>