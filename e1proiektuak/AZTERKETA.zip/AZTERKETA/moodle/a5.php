<?php
header("Content-Type: application/json; charset=UTF-8");

require_once "db.php";

$db = new DB;
$db->konektatu();

$metodoa = $_SERVER['REQUEST_METHOD'];

switch ($metodoa) {
    case 'GET':
        $mendiakBistaratu = [];

        foreach ($db->selectAll() as $mendiak) {
            $mendiakBistaratu[] = [
                "id" => $mendiak['id'],
                "izena" => $mendiak['izena'],
                "lurraldea" => $mendiak['lurraldea'],
                "altuera" => $mendiak['altuera'],
                "distantzia" => $mendiak['distantzia'],
                "desnibela" => $mendiak['desnibela']
            ];
        }
        http_response_code(200);
        echo json_encode($mendiakBistaratu, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    case 'DELETE':

        /*
    DELETE eskaeraren gorputza (adibidea):
    {"ezabatu": [{"id": 3}, {"id": 8}, {"id": 99}]}

    DELETE eskaeraren erantzuna (adibidea):
    {"ezabatuak": [3, 8], "ez_daudenak": [99]}
    */
}
