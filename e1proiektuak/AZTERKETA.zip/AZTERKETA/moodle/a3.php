<?php

require_once "db.php";

$db = new DB;

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $lurraldea = $_POST["lurraldea"];
    $altueraMin = $_POST["altueraMin"];

   $errore = "Ez dago baldintzak betetzen dituen mendirik";

    if ($altueraMin < 0 && $altueraMin > 2500) {
        $errore = "Ez dago baldintzak betetzen dituen mendirik";
    }
}

?>

<!DOCTYPE html>
<html lang="eu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>A3</title>
</head>

<body>
    <div style='border: 2px solid black'>
        <?php

        if (empty($errore)) {
            foreach ($db->selectAll() as $emaitza) {
                echo "<p>" . $emaitza->izena . "</p>";
                echo "<p>" . $emaitza->lurraldea . "</p";
                echo "<p>" . $emaitza->altuera . "</p>";
            }
        } else {
            echo "<p>$errore</p>";
        }

        ?>
    </div>

    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
        <label>Lurraldea: </label>

        <select name="lurraldea">
            <option value="">Guztiak</option>
            <option value="Araba">Araba</option>
            <option value="Bizkaia">Bizkaia</option>
            <option value="Gipuzkoa">Gipuzkoa</option>
            <option value="Nafarroa">Nafarroa</option>
        </select>
        <br>
        <label>Altuera minimoa (m): </label>

        <input type="text" name="altueraMin">
        <br>
        <input type="submit" value="Bilatu">
    </form>
</body>

</html>